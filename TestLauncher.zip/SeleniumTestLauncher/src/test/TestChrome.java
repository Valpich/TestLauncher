package test;

import static org.testng.Assert.fail;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class TestChrome {

	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();

	@BeforeClass(alwaysRun = true)
	public void setUp() throws Exception {
		driver = new RemoteWebDriver(new URL("http://localhost:9515"), DesiredCapabilities.chrome());
		baseUrl = "https://www.google.com";
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@Test
	public void test1() throws InterruptedException {
		driver.get(baseUrl);
		Thread.sleep(5000);

		System.out.println("Lancement du test " + Thread.currentThread().getStackTrace()[1].getMethodName());
		Thread.sleep(1000);

		WebElement element = driver.findElement(By.name("q"));
		Thread.sleep(5000);

		System.out.println(element);
		element.sendKeys("Test !\n");
		Thread.sleep(5000);

		(new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.id("resultStats")));
		Thread.sleep(5000);

		List<WebElement> findElements = driver.findElements(By.xpath("//*[@id='rso']//h3/a"));
		Thread.sleep(5000);

		for (WebElement webElement : findElements) {
			System.out.println(webElement.getAttribute("href"));
		}

		System.out.println("Fin du test " + Thread.currentThread().getStackTrace()[1].getMethodName());
		Thread.sleep(1000);

	}

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

}
