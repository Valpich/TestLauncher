package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class TestFirefox {

	private WebDriver driver;
	private String baseUrl;

	@Test
	public void test1() throws InterruptedException {
		driver.get(baseUrl);
		Thread.sleep(5000);

		System.out.println("Lancement du test " + Thread.currentThread().getStackTrace()[1].getMethodName());
		Thread.sleep(1000);

		WebElement element = driver.findElement(By.name("q"));
		Thread.sleep(5000);

		System.out.println(element);
		element.sendKeys("Test !\n");
		Thread.sleep(5000);

		(new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.id("resultStats")));
		Thread.sleep(5000);

		List<WebElement> findElements = driver.findElements(By.xpath("//*[@id='rso']//h3/a"));
		Thread.sleep(5000);

		for (WebElement webElement : findElements) {
			System.out.println(webElement.getAttribute("href"));
		}

		System.out.println("Fin du test " + Thread.currentThread().getStackTrace()[1].getMethodName());
		Thread.sleep(1000);
	}

	@BeforeClass
	public void beforeClass() {
		System.setProperty("webdriver.gecko.driver",
				"C:\\Users\\Valentin Pichavant\\Documents\\SeleniumTestLauncher\\lib\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		baseUrl = "http://www.google.com";
	}

	@AfterClass
	public void afterClass() {
		driver.quit();
	}

}
