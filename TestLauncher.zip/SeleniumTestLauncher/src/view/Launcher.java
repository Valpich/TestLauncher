package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

import org.testng.TestListenerAdapter;
import org.testng.TestNG;
import org.testng.annotations.Test;

import com.sun.javafx.PlatformUtil;

public class Launcher {

  private JFrame frame;

  private final JFileChooser fc = new JFileChooser();
  private final Logger log = Logger.getLogger(Launcher.class.getName());
  
  public static void main(String[] args) {
    EventQueue.invokeLater(new Runnable() {
      public void run() {
        try {
          Launcher window = new Launcher();
          window.frame.setVisible(true);
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    });
  }

  public Launcher() {
    initialize();
  }

  private void initialize() {
    frame = new JFrame();
    frame.setBounds(100, 100, 450, 300);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setResizable(false);
    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    frame.setLocation(dim.width / 2 - frame.getSize().width / 2,
        dim.height / 2 - frame.getSize().height / 2);
    frame.setTitle("Application de test seleniums");
    JButton btnNewButton = new JButton("Compiler et executer un test");
    btnNewButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        int returnVal = fc.showOpenDialog(frame);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
        	if (PlatformUtil.isWindows() || PlatformUtil.isWin7OrLater() || PlatformUtil.isWinVistaOrLater()){
        		System.out.println("Windows OS detected !");
        		compileAndExecuteWindows();
        	} else if (PlatformUtil.isLinux() || PlatformUtil.isMac()) {
        		System.out.println("Linux/MacOS OS detected !");
        		compileAndExecuteLinux();
        	}
        }
      }
      private void compileAndExecuteWindows() {
  		File file = fc.getSelectedFile();
            try {
              String libPath = file.getPath().substring(0,file.getPath().lastIndexOf("\\src"))+"\\lib\\";
              String[] cmd = {"cmd.exe","/c","javac -cp \"" + libPath + "*\" \"" + file.getPath()+"\""};
              log.log(Level.INFO, "Command is "+ cmd[2].toString());
              Process pb = Runtime.getRuntime().exec(cmd);
              try {
                pb.waitFor();
              } catch (InterruptedException e1) {
                  log.log(Level.INFO, e1.getMessage());
              }
            } catch (Error | IOException error) {
              log.log(Level.INFO, error.getMessage());
            }
            String path = file.getPath().substring(0, file.getPath().lastIndexOf("\\") + 1);
            String className =
                file.getPath().substring(file.getPath().lastIndexOf("\\") + 1).replace(".java", "");
            log.info("Starting test : path="+path+"; package=test.; className="+className);
            try {
          	  Class<?> clazz = getClassFromFile(path, "test." + className);
          	  System.out.println(clazz);
              lancerUnTest(clazz);
            } catch (Exception e1) {
                log.log(Level.INFO, e1.getMessage());
            }
  	}
      
	private void compileAndExecuteLinux() {
		File file = fc.getSelectedFile();
          try {
            String basePath = Launcher.class.getResource("Launcher.class").getPath()
                .replace("view/Launcher.class", "");
            String[] cmd = {"/bin/bash", "-c", "javac -cp .:" + basePath + "* " + file.getPath()};
            log.log(Level.INFO, cmd[2].toString());
            Process pb = Runtime.getRuntime().exec(cmd);
            try {
              pb.waitFor();
            } catch (InterruptedException e1) {
                log.log(Level.INFO, e1.getMessage());
            }
          } catch (Error | IOException error) {
            log.log(Level.INFO, error.getMessage());
          }
          String path = file.getPath().substring(0, file.getPath().lastIndexOf("/") + 1);
          String className =
              file.getPath().substring(file.getPath().lastIndexOf("/") + 1).replace(".java", "");
          try {
        	  Class<?> clazz = getClassFromFile(path, "test." + className);
        	  System.out.println(clazz);
        	  lancerUnTest(clazz);
          } catch (Exception e1) {
              log.log(Level.INFO, e1.getMessage());
          }
	}
    }
    );
    frame.getContentPane().add(btnNewButton, BorderLayout.CENTER);
  }

  private static Class<?> getClassFromFile(String path, String fullClassName) throws Exception {
    URLClassLoader loader = new URLClassLoader(new URL[] {new URL("file://" + path)});
    Class<?> clazz = loader.loadClass(fullClassName);
    loader.close();
    return clazz;
}


  private void lancerUnTest(Class<?> classe) {
    new Thread(() -> tester(classe)).start();
  }

  @Test
  private void tester(Class<?> classe) {
    TestListenerAdapter tla = new TestListenerAdapter();
    TestNG testng = new TestNG();
    testng.setTestClasses(new Class[] {classe});
    testng.addListener(tla);
    testng.run();
  }
}
